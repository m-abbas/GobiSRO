<?php
class Form extends ActiveRecord\Model
{
	static $serialize = array('data');
};
?>