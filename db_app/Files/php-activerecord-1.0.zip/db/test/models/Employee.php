<?php
class Employee extends ActiveRecord\Model
{
	static $has_one;
};
?>