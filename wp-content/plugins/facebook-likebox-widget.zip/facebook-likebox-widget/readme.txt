=== Facebook Likebox Widget ===

Contributors: Dakola, Dezmonde, Dezmonde Agence Web

Donate link: http://api.baoyam.com/faire-un-don/

Tags: facebook, social, widget, sidebar, multisite,wpmu, like box, likebox, plugin, seo, increase traffic, fb, fb like, referencement, module social facebook

Requires at least: 2.2.0

Tested up to: 3.5

Stable tag: 3.5

License: GPLv2 or later




== Description ==

= English =
Easily add a Facebook Like Box to your site using a widget. 

= Fran&ccedil;ais =
Ajoutez facilement une Facebook Like Box &agrave; votre site gr&acirc;ce &agrave; un widget.

= Deutsch =
Einfaches Hinzuf&uuml;gen eines Facebook Like Box auf Ihre Website durch ein Widget.

= Italiano =
Facilmente aggiungere un Facebook Like Box al tuo sito tramite un widget.

= Portugu&ecirc;s =
Facilmente adicionar um Facebook como caixa ao seu site atrav&eacute;s de um widget.

= Espag&ntilde;ol =
A&ntilde;ade f&aacute;cilmente a Facebook como la caja a su sitio a trav&eacute;s de un widget.

= Dansk =
Du kan nemt tilf&oslash;je en Facebook Ligesom Box til dit websted ved hj&aelig;lp af en widget.


== Installation ==

= English =

1. Unzip the file.
2. Copy  'facebook-likebox-widget' folder in your worpress insatallation pligins folder (/wp-content/plugins/). 
3. Go to 'Plugins' and activate  'Facebook LikeBox Widget'. 
4. Go to  'Appearence' then 'Widgets' and find the 'Facebook LikeBox Widget' widget.
5. Drag and drop it intto the sidbar.

= Fran&ccedil;ais =

1. D&eacute;zippez le fichier.
2. Copiez le dossier 'facebook-likebox-widget'  dans le dossier des plugins de votre site Web (/wp-content/plugins/).
3. Allez &agrave; 'Extensions' et activez  'Facebook LikeBox Widget'. 
4. Allez &agrave; 'Apparences' puis 'Widgets' et retrouvez le widget 'Facebook LikeBox Widget'.
5. Glissez le widget dans une des zones de widgets, et configurez le &agrave; votre choix .

== Frequently Asked Questions ==

= Question 1 =

Reponse 1


== Screenshots ==

1. Facebook Likebox Widget
2. Configurate the widget


== Changelog ==
= 3.4 = 

* Small fix of translations


= 3.2 = 

* Bugs fixed
* Removed hidden links

= 3.0 = 

* Faster Facebook Like Box display


= 2.5 = 

* Faster Facebook Like Box display
* Added Russian translation
* Better translations

= 2.2 = 

* Fixed this bug : The height of the box cannot ne modified
* Added Danish translation
* Better translations

= 2.0 =

* Added German translation
* Added Italian translation
* Added Spanish translation
* Added Portuguese translation
* Fixed some bugs

= 1.1 = 

* Improved speed

= 1.0 = 

* Added a Facebook Like Box Widget

* Added French language support


== Upgrade Notice ==

Nothing for now



